/*
 * mlt_openfx.h -- common mlt functions for OpenFX plugins
 * Copyright (C) 2025-2026 Meltytech, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef MLT_OPENFX_H
#define MLT_OPENFX_H

#include <dlfcn.h>
#include <framework/mlt.h>
#include <ofxCore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

typedef OfxStatus (*OfxSetHostFn)(const OfxHost *host);
typedef OfxPlugin *(*OfxGetPluginFn)(int nth);
typedef int (*OfxGetNumberOfPluginsFn)(void);

typedef enum {
    mltofx_prop_none = 0,
    mltofx_prop_int = 1,
    mltofx_prop_string = 2,
    mltofx_prop_double = 8,
    mltofx_prop_pointer = 16,
    mltofx_prop_color = 32,
    mltofx_prop_double2d = 64,
    mltofx_prop_int2d = 128,
    mltofx_prop_double3d = 256,
    mltofx_prop_int3d = 512,
} mltofx_property_type;

typedef enum {
    mltofx_depth_none = 0,
    mltofx_depth_byte = 1,
    mltofx_depth_short = 2,
    mltofx_depth_half = 4,
    mltofx_depth_float = 8,
} mltofx_depths_mask;

typedef enum {
    mltofx_components_none = 0,
    mltofx_components_rgb = 1,
    mltofx_components_rgba = 2,
} mltofx_components_mask;

// Set to 1 to print OpenFX discovery diagnostics during repository initialization.
#ifndef MLTOFX_DISCOVERY_DIAGNOSTICS
#define MLTOFX_DISCOVERY_DIAGNOSTICS 0
#endif

// Optional plugin identifier substring filter for diagnostics (example: "MergeDifference").
// Set to NULL or "" to log all detected OpenFX plugins.
#ifndef MLTOFX_DISCOVERY_DIAGNOSTICS_PLUGIN
#define MLTOFX_DISCOVERY_DIAGNOSTICS_PLUGIN NULL
#endif

static inline int mltofx_discovery_diagnostics_enabled(const char *plugin_identifier)
{
#if MLTOFX_DISCOVERY_DIAGNOSTICS
    const char *filter = MLTOFX_DISCOVERY_DIAGNOSTICS_PLUGIN;
    if (!filter || !filter[0])
        return 1;
    return plugin_identifier && strstr(plugin_identifier, filter);
#else
    (void) plugin_identifier;
    return 0;
#endif
}

void mltofx_init_host_properties(OfxPropertySetHandle host_properties);

void mltofx_create_instance(OfxPlugin *plugin, mlt_properties image_effect);

void mltofx_destroy_instance(OfxPlugin *plugin, mlt_properties image_effect);

void mltofx_set_source_clip_data(OfxPlugin *plugin,
                                 mlt_properties image_effect,
                                 uint8_t *image,
                                 int width,
                                 int height,
                                 mlt_image_format format,
                                 double pixel_aspect_ratio,
                                 const char *ofx_depth,
                                 int top_left_origin);

void mltofx_set_output_clip_data(OfxPlugin *plugin,
                                 mlt_properties image_effect,
                                 uint8_t *image,
                                 int width,
                                 int height,
                                 mlt_image_format format,
                                 double pixel_aspect_ratio,
                                 const char *ofx_depth,
                                 int top_left_origin);

int mltofx_detect_plugin(OfxPlugin *plugin);

void *mltofx_fetch_params(OfxPlugin *plugin, mlt_properties params, mlt_properties mlt_metadata);

void mltofx_param_set_value(mlt_properties params, char *key, mltofx_property_type type, ...);

void mltofx_set_render_scale(mlt_properties image_effect, double scale_x, double scale_y);

void mltofx_set_project_properties(mlt_properties image_effect,
                                   int width,
                                   int height,
                                   double pixel_aspect_ratio,
                                   double fps,
                                   double duration);

int mltofx_allows_frame_threading(mlt_properties image_effect);

void mltofx_get_clip_preferences(OfxPlugin *plugin, mlt_properties image_effect);

void mltofx_get_region_of_definition(OfxPlugin *plugin,
                                     mlt_properties image_effect,
                                     double ofx_time);

void mltofx_get_regions_of_interest(
    OfxPlugin *plugin, mlt_properties image_effect, double ofx_time, double width, double height);

void mltofx_begin_sequence_render(OfxPlugin *plugin, mlt_properties image_effect, double ofx_time);

void mltofx_end_sequence_render(OfxPlugin *plugin, mlt_properties image_effect, double ofx_time);

void mltofx_action_render(
    OfxPlugin *plugin, mlt_properties image_effect, double ofx_time, int width, int height);

mltofx_depths_mask mltofx_plugin_supported_depths(mlt_properties image_effect);

mltofx_components_mask mltofx_plugin_supported_components(mlt_properties image_effect);

uint16_t *mltofx_rgba64_to_half(const uint16_t *src, int n_pixels);

void mltofx_half_to_rgba64(const uint16_t *src, uint16_t *dst, int n_pixels);

float *mltofx_rgba64_to_float(const uint16_t *src, int n_pixels);

void mltofx_float_to_rgba64(const float *src, uint16_t *dst, int n_pixels);

#endif
