# Codex 云端交接包

上传本 ZIP 到你实际要执行的 Codex 任务，把 `CODEX_PROMPT.md` 全文作为提示词。解压后在本目录运行。

包含：
- 最小 MLT 局部渲染适配器、C helper、完整测试、合成素材生成器。
- 两张 AppKit 已栅格化的字幕 PNG；Linux 无需安装或调用 AppKit。
- MLT 7.42.0 上游源码压缩包及其内含许可证，供云端离线解压编译，避免 GitHub 下载受限。
- 架构文档、Phase 0 报告、局部渲染报告；Mac 对照证据单独位于 `reference/macos/`。
- 清单、文件 SHA-256 校验器、云端构建与测试入口、GitHub 提交要求。

不包含：Homebrew/Mac runtime、编译产物、原始 RAW 视频、完整合成媒体、RGBA/PCM 临时数据、密钥或聊天迁移记录。其余媒体由脚本生成。

## 执行

```sh
python3 verify_bundle.py
bash local_render/cloud_setup.sh
```

第二步需要 Linux 系统中已有开发依赖。本包不是完全离线的操作系统镜像。Debian/Ubuntu 包清单（由 Codex 按云端权限安装）：

```text
build-essential cmake pkg-config python3 ffmpeg
libavcodec-dev libavdevice-dev libavfilter-dev libavformat-dev libavutil-dev
libswscale-dev libswresample-dev libxml2-dev libsox-dev libsamplerate0-dev
```

`cloud_setup.sh` 使用附带源码编译最少模块 core/avformat/xml/sox，默认安装至 /tmp/mlt-7.42.0，默认编译并行度 2。`MLT_BUILD_JOBS` 可按云端资源调整。已存在合适系统 MLT 时：

```sh
MLT_SYSTEM=1 python3 local_render/run_all.py
```

注意：`local_render/README.md` 中的旧 Mac runtime 路径只适用于原机器；该 runtime 刻意未放入本包。Linux 必须使用上述 system 路径或 cloud_setup.sh。

## 如何读结果

新执行结果生成到 `local_render/results/`，不会把 Mac 参考 JSON 当作云端结果。入口为 `SUITE.json`、`verification.json`、`session-probe.json`、`eos-tail.json`、`mux-verification.json`、`sample-clock.json`。

Mac 上曾有 118 次差分比较，其中 64 项精确断言通过；另含预热不足的预期失败。它们是对照，不能直接宣称云端通过。6 秒短时间线不能外推任意工程/任意滤镜；完整限制见 LOCAL_RENDER_REPORT.md。

GitHub 目标 https://github.com/turtlelnc/Editing-Tools.git ，分支 `mlt-local-render-validation`，完成验证后用户已授权 commit/push。GitHub 认证不随包携带。

本包已做归档完整性、文件哈希、Python 与 shell 语法检查；Linux 编译与云端测试尚未在本机执行。不要将打包检查误当成云端复验。
