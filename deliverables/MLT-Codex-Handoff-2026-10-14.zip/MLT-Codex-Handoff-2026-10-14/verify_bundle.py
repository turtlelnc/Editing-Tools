"""Validate source handoff before executing it. Python standard library only."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text());bad=[]
for row in manifest['files']:
 p=root/row['path']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:bad.append(row['path'])
if bad:print('FAILED',bad);sys.exit(1)
print('OK:',len(manifest['files']),'files verified; this is integrity validation, not a rendering test.')
